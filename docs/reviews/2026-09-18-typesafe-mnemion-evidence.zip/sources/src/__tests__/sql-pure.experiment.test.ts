// Tests for the enshrined SQL-identifier chokepoint (shared/core/sql.ts) and a
// behavioral check that routing the data engine through it left query/filter/sort
// working end-to-end.
//
// quoteIdent is the single transition map raw-string → SQL-identifier: it fuses
// validation (IDENTIFIER_RE) with quoting, so a raw unvalidated identifier — or an
// injection-bearing one — physically can't reach SQL. The unit tests pin the
// grammar + throw behavior; the DO test proves the fused chokepoint doesn't break
// a normal query.

import { describe, it, expect } from "vitest";
import { quoteIdent } from "../../shared/core/sql";

describe("quoteIdent — grammar", () => {
  it("returns a double-quoted identifier for valid names", () => {
    expect(quoteIdent("col")).toBe('"col"');
    expect(quoteIdent("tasks")).toBe('"tasks"');
    expect(quoteIdent("_members")).toBe('"_members"'); // leading underscore (kernel table)
    expect(quoteIdent("due-date")).toBe('"due-date"'); // hyphen is allowed
    expect(quoteIdent("a1")).toBe('"a1"');             // digit after a letter
    // Hyphens are part of the grammar, so `a--b` is a legitimate identifier — and
    // double-quoting it (`"a--b"`) renders the `--` inert as a SQL comment anyway.
    expect(quoteIdent("a--b")).toBe('"a--b"');
  });

  it("accepts the snake_case kernel columns", () => {
    for (const col of ["id", "version", "created_at", "updated_at", "archived_at", "created_by", "updated_by"]) {
      expect(quoteIdent(col)).toBe(`"${col}"`);
    }
  });

  it("THROWS on injection attempts and malformed identifiers", () => {
    const bad = [
      'x"; DROP TABLE y --', // quote-break + statement injection
      'x")',                 // quote-break
      "a b",                 // space
      "1col",                // leading digit
      "",                    // empty
      "UPPER",               // uppercase (grammar is lowercase-only)
      "a;b",                 // semicolon
      "a'b",                 // single quote
    ];
    for (const name of bad) {
      expect(() => quoteIdent(name), name).toThrow(/Invalid SQL identifier/);
    }
  });

  it("THROWS on a non-string", () => {
    expect(() => quoteIdent(undefined as any)).toThrow(/Invalid SQL identifier/);
    expect(() => quoteIdent(null as any)).toThrow(/Invalid SQL identifier/);
  });
});

