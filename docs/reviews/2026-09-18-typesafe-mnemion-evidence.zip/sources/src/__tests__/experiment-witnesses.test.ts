import { describe, it, expect } from "vitest";
import { readFileSync } from "node:fs";
import { resolveHost } from "../../shared/core/host";
import { quoteIdent } from "../../shared/core/sql";
import { scopeMatches } from "../../entities/Hive/kernel";
import { isBroadTokenScope } from "../../entities/Hive/policy";
describe("Focused experiment behavior", () => {
 it("configured host wins even with hostile observed input", () => {
  expect(resolveHost("owner.example", "attacker.example")).toBe("owner.example");
 });
 it("the literal never-observed-host sentence has an executable counterexample", () => {
  expect(resolveHost(undefined, "attacker.example")).toBe("attacker.example");
 });
 it("SQL invalid input throws", () => {
  expect(() => quoteIdent('x"; DROP TABLE y --')).toThrow();
 });
 it("SQL valid input is quoted", () => {
  expect(quoteIdent("due-date")).toBe('"due-date"');
 });
 it("the actual served pattern-and-id resource requires consent for a parent scope", () => {
  const io = readFileSync(new URL("../../shared/Routing/routes/io.ts", import.meta.url), "utf8");
  const kind = io.match(/`read:([a-z]+):\$\{ctx.params.pattern\}:\$\{ctx.params.id\}`/)![1];
  const parent = `read:${kind}:axioms`;
  expect(scopeMatches(parent, parent + ":7")).toBe(true);
  expect(scopeMatches(parent, parent + ":8")).toBe(true);
  expect(isBroadTokenScope(parent)).toBe(true);
 });
});
