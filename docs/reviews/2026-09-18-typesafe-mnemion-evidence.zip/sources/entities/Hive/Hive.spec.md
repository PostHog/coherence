# Hive

The single per-user Durable Object that owns all SQLite data and funnels every agent write through one kernel-enforced chokepoint.

## invariants
- kernel write boundary: An agent write reaches a kernel pattern only through the write class its policy declares, and an unclassified kernel pattern is denied.
  protects: KERNEL_WRITE_POLICY in policy.ts
  chokepoint: writeClass
  over: every kernel pattern in KERNEL_TABLES
  via: write-policy totality
  because: the write boundary reaches the engine over two transports, the MCP mutate tool and the browser-authenticated /api/mutate; with the decisions inlined in the MCP handler, an /api and RPC test passed while the MCP Zod and consent layer silently broke, so enforcement disagreed across the two paths a write can take. Pure decisions in one dependency-free leaf shared by both transports is the fix, and an unclassified pattern fails closed (System, denied) so a new pattern can never quietly become agent-writable
  crossing: agent-mcp -> storage
  refuted: renamed the _members row key in CORE_KERNEL_WRITE_POLICY, leaving the _members kernel table unclassified -> the full verify run went red by name: write-policy totality failed with kernel pattern _members has no write-class policy (defaults to System/denied), while the fail-closed default held; restore returned it green. The fast run skips the totality tests by design, so the red appears only in the full run (2026-08-20)
  kinds: storage
  checklist: scoped-reads declared as kernel read+write capability
  checklist: encrypted-storage dismissed: the hive stores no ciphertext; secrets are stored as digests (born-hashed secrets)
  checklist: key-rotation-compatibility dismissed: no encryption key exists to rotate
  checklist: input-validation declared as immutable-field enforcement
  checklist: revision-preservation dismissed: the write class decides who may write, not how history is kept
  checklist: commit-ordered-effects declared as pattern-effects totality
  checklist: durable-dispatch-intent dismissed: post-mutate effects run inside the one Durable Object; no external dispatcher
  checklist: declared-target-coverage dismissed: one SQLite store, no fan-out
  checklist: completion-evidence dismissed: a write completes in the same synchronous transaction
- kernel read+write capability: A kernel pattern is read or written only through a trusted data context, and an untrusted context can neither read nor write one.
  protects: the kernel tables (KERNEL_TABLES) reached through the query engine in data.ts
  chokepoint: query
  over: every served read path and every untrusted write path
  via: context-capability totality
  because: trust is a capability, not a per-call-site rule. HiveDO exposes two named constructors over trust-agnostic fields, ownerDataCtx (the only trusted one) and servedDataCtx, with no trust parameter to dial at a call site, so served reads (public page, OG card, publication, /o entry) and untrusted writes (ingress, upload) physically cannot reach kernel data. All served reads live in served.ts behind a narrow ServedContext exposing servedQuery plus single-answer kernel-config lookups, never db and never a trusted context; the old per-sink isKernelPattern checks were a block-list that failed open, and deleting them left one chokepoint instead of a guard to forget per sink
  crossing: served-untrusted -> storage
  refuted: the same break (unclassified _members) -> context-capability totality also went red (an untrusted ingress write to a kernel pattern is refused at the capability check), showing the capability derives from the same policy and fails loudly with it; green on restore (2026-08-20)
  kinds: read
  checklist: scoped-reads declared as kernel read+write capability
  checklist: redaction declared as egress-sensitivity totality
- egress-sensitivity totality: Every column declared secret or redact is stripped from a row before the row leaves the hive.
  protects: the secret and redact column declarations of every feature, composed into one registry
  chokepoint: SENSITIVE_COLUMNS
  over: every feature that declares a secret or redact column
  via: egress-sensitivity totality
  because: the bug it kills was a false check. Write policy and sensitive columns were composed from two parallel hand-lists, the second silently omitted a feature (pages), and the egress side had no totality check at all, so a forked feature that declared a redact or secret column but forgot the second line got no seal, audit, or export redaction and no boot warning. findUnclassifiedSensitiveColumns stays as a complementary name heuristic only; it cannot see a sensitive column with an innocuous name
  crossing: storage -> public-egress
- pattern-effects totality: Every pattern that needs a post-mutate effect has that effect registered, composed from the live feature list.
  protects: each feature's effects declaration
  chokepoint: PATTERN_EFFECTS
  over: every effect-bearing pattern in FEATURES
  via: pattern-effects totality
  because: post-mutate side effects (re-embed, cache invalidate, broadcast) were a hand-coded if-pile in mutate; a feature adding a pattern that needed an effect had to remember to extend the tree, and a forgotten branch silently did nothing at runtime. Composing the effect set from FEATURES with a check that every effect-bearing pattern is represented turns a missing entry into a build failure
- facet/kernel-column collision: A user-proposed facet never collides with a kernel column, and reserved plus overridable columns together equal KERNEL_COLUMNS.
  protects: KERNEL_COLUMNS in kernel-columns.ts
  chokepoint: FACET_RESERVED_COLUMNS
  over: every kernel column
  via: facet-kernel-collision totality
  because: a hand-narrowed reserved subset once omitted created_by and updated_by (a same-named facet is a duplicate-column DDL error), and over-correcting to reserve version broke the user-version feature, since a pattern may declare its own semver semantics. Splitting overridable into its own declaration fixes both directions at once: neither under- nor over-reserving can recur
- data-is-destiny no-hybrid: A pattern never stores an aggregate of rows it also retains.
  over: every pattern with an aggregate-named facet and a child pattern referencing it
  via: data-is-destiny no-hybrid totality
  because: store truth once and derive the rest is semantic in general, but it has a decidable core, and findStoredDerivedAggregates checks exactly that, firing only when both halves are present. A bare counter with no retained instances is the stored truth, not a denormalization, so it stays silent there; boot warns rather than throws because a deliberate materialized aggregate is a valid reviewed override
- credential-mint gating: A create on a pattern with a secret column requires a consent round-trip whenever the minted scope is broad.
  over: every pattern in SENSITIVE_COLUMNS with a secret column, against KERNEL_WRITE_POLICY
  via: credential-mint gating totality
  because: a pattern with a secret column mints a bearer on every create, so create is the dangerous operation; patch_only declared it benign, and that shipped: _access_tokens was patch_only, so an injected agent could mint a broad token (a full owner login, redeemable at /auth/verify) in one un-round-tripped mutate and exfiltrate it. on_broad_token makes a broad or portable scope round-trip like every other standing grant while narrow target-bound and inert scopes stay cheap, and the rule derives from SENSITIVE_COLUMNS and KERNEL_WRITE_POLICY so reclassifying a minter as patch_only is unexpressible
  crossing: agent-mcp -> owner-trusted
- born-hashed secrets: A secret column is stored only as its digest; the preimage is returned once at create and never persisted.
  protects: every secret-classed column in SENSITIVE_COLUMNS
  chokepoint: mintSecrets
  over: every secret-classed column
  via: born-hashed-secret totality
  because: the storage dual of credential-mint gating, which governs when a bearer is minted; this governs how it is stored. mintSecrets is generic over the registry and runs on every engine write path, so only the SHA-256 digest lands in the column, the audit log, and the live delta, and findAccessToken compares digests, so a read of a token row (a query, a search hit, a leaked snapshot) yields a digest and never a usable bearer. This is the deliberate exception to store truth once: the preimage is never persisted, which neuters the whole class of a token reaching a read sink
  crossing: storage -> public-egress
- immutable-field enforcement: A kernel row's immutable fields cannot change after create on any write path, patch included.
  protects: the IMMUTABLE and IMMUTABLE_AFTER_CREATE registries in kernel.ts
  chokepoint: applyKernelRules
  over: every rule in IMMUTABLE and IMMUTABLE_AFTER_CREATE
  via: IMMUTABLE-registry totality
  because: where ON_CREATE decides what a kernel row may be born as, IMMUTABLE and IMMUTABLE_AFTER_CREATE decide what it may never become, the defense behind the consent model: approved_at and consumed_at are immutable so an agent cannot self-approve its invite or replay a single-use token, and a token's scope, member, constraints, and token, and an ingress endpoint's target_pattern are frozen after create so a row that passed create-time validation cannot be repointed at a stronger capability. Enforcement has two faces because patch edits one facet by name and sidesteps the top-level key scan: applyKernelRules covers create, update, and unarchive, immutableFieldError covers patch
  crossing: agent-mcp -> storage
- token-scope-grammar: A token scope is narrow only when it reaches its resource kind's leaf depth; anything shorter is broad and needs consent to mint.
  protects: the broad-or-narrow partition of token scopes that scopeMatches grants
  chokepoint: isBroadTokenScope
  over: every resource kind io.ts mints and scopeMatches grants
  via: broad-token scope-grammar totality
  because: the classifier dual of credential-mint gating. A bare parts-count cutoff classified read:entry:pattern (three parts) as narrow while scopeMatches prefix-grants it every entry in the pattern, a pattern-wide standing read key minted with no round-trip. Classifying by resource grammar instead (entry is a leaf at depth four, output, publication, document, and input at depth three) makes the short form broad, and the check reconciles the partition against both scopeMatches and the kinds io.ts mints so a new served resource kind cannot leave it incomplete
  crossing: agent-mcp -> owner-trusted
- SSRF block-host coverage: Federation refuses every class of non-public host in every encoding.
  protects: the outbound federation fetch in federation.ts
  chokepoint: isBlockedFederationHost
  over: every non-public host class (loopback, private, CGNAT, link-local IPv4 in every inet_aton encoding; the IPv6 loopback, ULA, link-local, mapped, NAT64, and 6to4 forms; the .localhost, .local, .internal, and .lan suffixes)
  via: SSRF block-host totality
  because: a dropped category is a silent SSRF reopening, the canonical target being the cloud-metadata address 169.254.169.254; correctness was remember every encoding with no completeness check, and the category-to-example table makes a new bypass class fail the build by name. Token-send and allow-list consent share one function, federatedResolve, re-validated on every redirect hop, so the approved host and the contacted host cannot come apart
  crossing: owner-trusted -> federated
- sql-identifier quoting: A SQL identifier reaches a query only validated and quoted by one function.
  protects: identifier interpolation in the query engine (data.ts)
  chokepoint: quoteIdent
  over: every identifier shape IDENTIFIER_RE admits and refuses
  via: quoteIdent — grammar
  because: the identifier crossing (a raw string becoming a table or column token) was validate, then interpolate at scattered sites, two separate steps a new site can forget. quoteIdent fuses them, throwing on any injection-bearing name, so an identifier that skipped the upstream semantic check still cannot carry injection; the semantic checks (facetMeta, isValidColumn, patternExists) stay primary with quoteIdent as the fail-closed floor beneath. DDL interpolation in schema.ts and evolution.ts is the tracked follow-up
  crossing: agent-mcp -> storage
- instance-identity host: Every capability URL is built from the configured host, never from the inbound Host header.
  protects: the host every generated capability URL is built from (currentHost)
  chokepoint: resolveHost
  over: configured, observed, and placeholder host inputs
  via: instance-identity host resolution
  because: an attacker who plants a spoofed Host on an unauthenticated request (a /ws upgrade, say) must not poison an upload_url, page_url, or og_image handed to the owner. currentHost enforced this by habit only; the decision is now the pure resolveHost (configured wins, else observed, else localhost, placeholder treated as unconfigured), which currentHost delegates to, so the test is the enforcement
  crossing: public-egress -> owner-trusted
- soft archive only: Archive is the only destructive operation and it is soft: an archived entry is excluded from reads and never deleted, so recovery is always possible.
  protects: <the rows of every pattern>
  chokepoint: <the one symbol every removal passes through>
  because: the served rules doc tells agents that nothing is ever deleted; the engine's archive case sets archived_at and reads filter on it, but nothing yet detects a path that deletes a row outright
  kinds: storage, revision
  checklist: scoped-reads dismissed: which rows a read may see is the capability invariant's
  checklist: encrypted-storage dismissed: nothing here is encrypted
  checklist: key-rotation-compatibility dismissed: no key
  checklist: input-validation dismissed: archive takes an id, validated by the mutate chokepoint
  checklist: revision-preservation declared as soft archive only
  checklist: commit-ordered-effects dismissed: archive has no external effect
  checklist: durable-dispatch-intent dismissed: no dispatch
  checklist: declared-target-coverage dismissed: one store
  checklist: completion-evidence dismissed: the archive lands in the same transaction
- kernel pattern prefix: A pattern is a kernel pattern exactly when its name starts with an underscore, and one function decides it everywhere.
  protects: <the kernel-or-user decision at every site that asks>
  chokepoint: isKernelPattern
  because: the decision once lived as eleven independent startsWith checks scattered across kernel, data, hive, and prime, and every missed cell was a hole; policy.ts collapsed them into isKernelPattern, but nothing yet detects a new site that spells the check itself
  kinds: identity
  checklist: capability-authorization dismissed: what a kernel pattern permits is the write class's
  checklist: canonical-encoding declared as kernel pattern prefix
  checklist: identity-continuity dismissed: a pattern is never renamed across the kernel line
- index derived never stored: The index is derived from the live patterns and entries on every read, never stored.
  over: <every field the index reports: patterns, descriptions, facets, counts, guidance>
  via: <the test that fails when an index field is read from a stored copy>
  because: the index is the single source of truth for what exists in the hive and the first thing an agent reads; a stored copy could disagree with the store it describes. getIndex in reports.ts computes it today, and nothing yet forbids a cached column
  kinds: read
  checklist: scoped-reads dismissed: the index is owner-scoped by construction
  checklist: redaction declared as egress-sensitivity totality
- visibility values enumerated: A visibility is exactly one of public, unlisted, or private, and any other value is refused at write.
  over: <every write path that accepts a visibility: kernel hooks, schema evolution, unarchive>
  via: <the test that fails when a visibility site accepts a value outside the enumeration>
  because: the served rules doc still describes two values while the kernel accepts three, and the list is spelled by hand at two validation sites (kernel.ts and evolution.ts) that can disagree; one enumeration every site derives from is the shape this needs
  kinds: read
  checklist: scoped-reads declared as served-read gating
  checklist: redaction dismissed: visibility decides who may read, not what is stripped
- system-doc edits consent-required: An edit to a system doc requires a consent round-trip, because it changes every future agent session.
  protects: <the _system_docs write path>
  chokepoint: <the one symbol every system-doc write passes through>
  because: system docs are read into every session's instructions, so a single injected edit would steer every later agent; the _system_docs row in KERNEL_WRITE_POLICY already carries the consent write class with condition always, but nothing yet witnesses that an edit without the round-trip is refused
  kinds: state
  checklist: revalidated-permission dismissed: the round-trip completes in one session
  checklist: separation-of-duties declared as system-doc edits consent-required
  checklist: legal-state-succession dismissed: a doc has no state machine; content or default_content
  checklist: supersession-safety dismissed: a single Durable Object serializes the write
  checklist: worker-fencing dismissed: no workers
  checklist: commit-ordered-effects dismissed: no external effect
  checklist: resumption-coverage dismissed: no batch
