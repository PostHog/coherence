const fs=require('fs');
const esbuild=require('/Users/daniloc/Documents/Dev/mnemion/mnemion-js/node_modules/esbuild');
const D='/tmp/coherence-typesafe.drDqhw';
const primary=JSON.parse(fs.readFileSync(D+'/cases.json','utf8'));
const variants=JSON.parse(fs.readFileSync(D+'/variants.json','utf8'));
const questions=JSON.parse(fs.readFileSync(D+'/questions.json','utf8'));
const clean=s=>esbuild.transformSync(s,{loader:'ts',legalComments:'none'}).code;
const unnumber=s=>s.split('\n').map(l=>l.replace(/^\d+: /,'')).join('\n');
const out=[];
for (const [id,old,kind,broadExpected] of [['c17','c10','entry','true'],['c18','c11','entry','false'],['c19','c13','collection','false']]){
 const c=primary.find(c=>c.id===old);
 const state={
  requirement:c.state.focal_behavior,
  implementation:c.state.sources.filter(s=>s.role.startsWith('implementation')||s.role.startsWith('dependency')).map(s=>({path:s.path,code:clean(unnumber(s.content))})),
  served_required_scopes:c.state.sources.find(s=>s.path.endsWith('io.ts')).content,
  inputs:{parent:`read:${kind}:axioms`,leaf_one:`read:${kind}:axioms:7`,leaf_two:`read:${kind}:axioms:8`},
  evidence_limits:'Executable functions transpiled from the corresponding primary case using esbuild with comments omitted. These are concrete input values, not expected outputs. No execution results supplied.'
 };
 const q={
  local_fit:{...questions.local_fit,instructions:'Compare requirement with the supplied executable functions and served required-scope construction sites. A parent scope that grants both distinct served leaves must be classified broad. Does the implementation support this behavior, contradict it, or lack necessary evidence? Do not infer behavior from names.'},
  broad_result:{type:'choice',instructions:'What boolean does isBroadTokenScope(inputs.parent) return under the supplied implementation? Evaluate the code for exactly that input.',criteria:{true:'Returns true',false:'Returns false',insufficient:'Cannot determine from the supplied code'}},
  grants_both:{type:'noul',instructions:'Do scopeMatches(inputs.parent, inputs.leaf_one) and scopeMatches(inputs.parent, inputs.leaf_two) both return true under the supplied implementation?'},
  behavioral_counterexample:{type:'noul',instructions:'For exactly inputs.parent, does the code classify it as narrow (isBroadTokenScope returns false) even though scopeMatches grants both of the distinct served leaf inputs? This conjunction, not either condition alone, would violate requirement.'}
 };
 out.push({id,primary_case:old,state,questions:q,expected_broad_result:broadExpected,expected_counterexample:id==='c17'?false:true,expected_local:id==='c17'?'supported':'contradicted'});
}
const t=variants.scope_detector_fixed.scope_test;
const shapeStart=t.indexOf('const SHAPES:');const shapeEnd=t.indexOf('\n  ];',shapeStart)+6;
const assertionStart=t.indexOf('const ioSource =');const assertionEnd=t.indexOf('\n  });',assertionStart);
const ioNew=primary.find(c=>c.id==='c13').state.sources.find(s=>s.path.endsWith('io.ts')).content;
out.push({id:'c20',state:{
 detector_code:clean(t.slice(shapeStart,shapeEnd)+'\n'+t.slice(assertionStart,assertionEnd)),
 dependency:'readFileSync is node:fs readFileSync. expect(value).toBe(true) fails exactly when value is not true.',
 io_ts_relevant_contents:ioNew,
 question_context:'Evaluate the detector after the shown io.ts change. File content is read by the code; SHAPES is the shown unchanged table. No runtime outcomes are supplied.'
},questions:{
 reads_actual_population:{type:'noul',instructions:'Does the detector derive SERVED_KINDS by reading the actual io.ts file and matching its required-scope construction sites, instead of using a separately maintained literal list?'},
 detects_new_kind:{type:'choice',instructions:'Given the supplied io.ts content with read:collection and the unchanged SHAPES table, what happens when the shown detector runs? Follow the file-read, regex, set, loop, and hasLeaf assertion.',criteria:{fails:'At least one hasLeaf or hasClass expectation fails for collection because SHAPES has no collection entries.',passes:'All shown expectations pass.',insufficient:'Necessary code or input content is missing.'}}
},expected_detects_new_kind:'fails'});
fs.writeFileSync(D+'/diagnostic-cases.json',JSON.stringify(out,null,2));
console.log(out.map(c=>[c.id,JSON.stringify(c.state).length]));
