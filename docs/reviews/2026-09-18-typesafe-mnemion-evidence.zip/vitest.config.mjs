export default {
  cacheDir: '/tmp/coherence-typesafe.drDqhw/vite-cache',
  test: {
    environment: 'node',
    globals: true,
    cache: false,
    isolate: true,
    maxWorkers: 1,
    fileParallelism: false,
    include: ['src/__tests__/host-resolution.test.ts', 'src/__tests__/scope-grammar.test.ts', 'src/__tests__/sql-pure.experiment.test.ts', 'src/__tests__/experiment-witnesses.test.ts'],
  },
};
