from pathlib import Path
import os,json,time,urllib.request,urllib.error
D=Path('/tmp/coherence-typesafe.drDqhw');key=os.environ.pop('TYPESAFE_API_KEY')
prior=json.loads((D/'api-manifest.json').read_text())['http_calls'];rows=[]
try:
 for i,case in enumerate(json.loads((D/'diagnostic-cases.json').read_text())):
  if prior+i>=20: raise RuntimeError('Twenty-request cap reached')
  payload={'model':'jev-1.13.0','state':case['state'],'questions':case['questions']}
  encoded=json.dumps(payload).encode();(D/'requests'/f"{case['id']}.json").write_bytes(encoded)
  req=urllib.request.Request('https://api.typesafe.ai/v1/systemone',data=encoded,headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'},method='POST')
  start=time.monotonic()
  try:
   with urllib.request.urlopen(req,timeout=90) as response: result=json.load(response)
  except urllib.error.HTTPError as exc:
   print('HTTP error',exc.code,exc.read().decode(errors='replace').replace(key,'[REDACTED]')[:300]);break
  (D/'responses'/f"{case['id']}.json").write_text(json.dumps(result,indent=2))
  row={'case_id':case['id'],'seconds':round(time.monotonic()-start,3),'model':result.get('model'),'answers':result['answers'],'usage':result.get('usage',{})};rows.append(row)
  print(case['id'],json.dumps(row),flush=True)
finally:
 (D/'diagnostic-results.json').write_text(json.dumps(rows,indent=2));key=None
