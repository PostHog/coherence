from pathlib import Path
import json,statistics,hashlib
D=Path('/tmp/coherence-typesafe.drDqhw')
a=json.loads((D/'api-results.json').read_text());b=json.loads((D/'diagnostic-results.json').read_text());cases={c['id']:c for c in json.loads((D/'cases.json').read_text())}
unique=[r for r in a if 'repeat_of' not in cases[r['case_id']]]
metrics={
 'primary_requests':len(a),'unique_primary_cases':len(unique),'adaptive_requests':len(b),'http_requests_total':len(a)+len(b),
 'primary_unique_local_matches':sum(r['answers']['local_fit']['choice']==cases[r['case_id']]['expected_local'] for r in unique),
 'primary_unique_coverage_matches':sum(r['answers']['coverage_fit']['choice']==cases[r['case_id']]['expected_coverage'] for r in unique),
 'deliberate_behavior_changes':[{'case_id':r['case_id'],'detected_by_local_fit':r['answers']['local_fit']['choice']=='contradicted'} for r in unique if cases[r['case_id']]['expected_local']=='contradicted'],
 'omitted_implementation':[{'case_id':r['case_id'],'abstained':r['answers']['local_fit']['choice']=='insufficient'} for r in unique if cases[r['case_id']]['expected_local']=='insufficient'],
 'input_tokens':sum(r['usage']['input_tokens'] for r in a+b),'output_tokens':sum(r['usage']['output_tokens'] for r in a+b),
 'latency_seconds':{'median':statistics.median(r['seconds'] for r in a+b),'minimum':min(r['seconds'] for r in a+b),'maximum':max(r['seconds'] for r in a+b),'sum':sum(r['seconds'] for r in a+b)},
 'price_per_million_input_tokens_usd':0.042,
 'price_source':'https://docs.typesafe.ai/models.md',
 'pricing_checked_on':'2026-09-18',
 'billing_verified':False,
 'target_commit':'02efce9da182ba7d543e47d8694f39ef9794ed46',
 'target_status_unchanged':(D/'target-status-before.txt').read_bytes()==(D/'target-status-after.txt').read_bytes(),
 'target_diff_unchanged':(D/'target-diff-before.txt').read_bytes()==(D/'target-diff-after.txt').read_bytes(),
}
metrics['estimated_api_cost_usd']=metrics['input_tokens']/1e6*metrics['price_per_million_input_tokens_usd']
(D/'summary.json').write_text(json.dumps(metrics,indent=2))
print(json.dumps(metrics,indent=2))
print('\nPRIMARY ROWS')
for r in unique:
 c=cases[r['case_id']]; ans=r['answers']
 print('| '+ ' | '.join([r['case_id'],c['family']+' — '+c['label'],c['expected_local'],ans['local_fit']['choice'],str(ans['local_fit']['confidence']),c['expected_coverage'],ans['coverage_fit']['choice']])+' |')
