# Mnemion / TypeSafe experiment evidence

See the accompanying report for interpretation and limitations. Initial cases c01-c14 were distinct, c15 repeats c01, and c16 repeats c10. c17-c20 are adaptive diagnostic cases. Expected outcomes occur in cases.json and diagnostic-cases.json, never in requests/.

The target source is commit 02efce9da182ba7d543e47d8694f39ef9794ed46. sources/ contains selected original or explicitly derived local test files, not a complete checkout. The SQL pure suite omits the Cloudflare integration part; experiment-witnesses.test.ts was written for this experiment. variants.json contains the alternative source versions. Historical scripts and commands preserve their original absolute temporary/dependency paths; they need path adjustment to rerun on another machine.

To replay HTTP requests, obtain a fresh credential, make it available in the TYPESAFE_API_KEY environment variable without saving it in this archive, and run:

    python3 replay.py --out /tmp/mnemion-typesafe-replay --cases c01 c02

The helper reads saved request bodies, uses the same pinned model, and writes only new responses/timings. API use may incur charges; current availability and pricing must be checked separately. It does not run local tests. The archive contains no API credential.

Raw local test JSON/logs retain exact assertions and commands. Source status/diff hashes prove comparison, not a new clean checkout: Mnemion had an existing config change which was left alone. API token cost is calculated from the published model price observed on September 18, 2026, not from billing records.
