from pathlib import Path
import subprocess,json,time
D=Path('/tmp/coherence-typesafe.drDqhw'); R=D/'snapshot/mnemion-js'
files={'host':'shared/core/host.ts','sql':'shared/core/sql.ts','policy':'entities/Hive/policy.ts','io':'shared/Routing/routes/io.ts','sql_test':'src/__tests__/sql-pure.experiment.test.ts','scope_test':'src/__tests__/scope-grammar.test.ts'}
original={k:(R/v).read_text() for k,v in files.items()}
variants=json.loads((D/'variants.json').read_text())
config=D/'vitest.config.mjs'
config.write_text(config.read_text().replace("'src/__tests__/sql-pure.experiment.test.ts']","'src/__tests__/sql-pure.experiment.test.ts', 'src/__tests__/experiment-witnesses.test.ts']"))
(R/'src/__tests__/experiment-witnesses.test.ts').write_text('''import { describe, it, expect } from "vitest";
import { readFileSync } from "node:fs";
import { resolveHost } from "../../shared/core/host";
import { quoteIdent } from "../../shared/core/sql";
import { scopeMatches } from "../../entities/Hive/kernel";
import { isBroadTokenScope } from "../../entities/Hive/policy";
describe("Focused experiment behavior", () => {
 it("configured host wins even with hostile observed input", () => {
  expect(resolveHost("owner.example", "attacker.example")).toBe("owner.example");
 });
 it("the literal never-observed-host sentence has an executable counterexample", () => {
  expect(resolveHost(undefined, "attacker.example")).toBe("attacker.example");
 });
 it("SQL invalid input throws", () => {
  expect(() => quoteIdent('x"; DROP TABLE y --')).toThrow();
 });
 it("SQL valid input is quoted", () => {
  expect(quoteIdent("due-date")).toBe('"due-date"');
 });
 it("the actual served pattern-and-id resource requires consent for a parent scope", () => {
  const io = readFileSync(new URL("../../shared/Routing/routes/io.ts", import.meta.url), "utf8");
  const kind = io.match(/`read:([a-z]+):\$\{ctx.params.pattern\}:\$\{ctx.params.id\}`/)![1];
  const parent = `read:${kind}:axioms`;
  expect(scopeMatches(parent, parent + ":7")).toBe(true);
  expect(scopeMatches(parent, parent + ":8")).toBe(true);
  expect(isBroadTokenScope(parent)).toBe(true);
 });
});
''')
base=['node','/Users/daniloc/Documents/Dev/mnemion/mnemion-js/node_modules/vitest/vitest.mjs','run','--root',str(R),'--config',str(config),'--reporter=json']
original_tests=['src/__tests__/host-resolution.test.ts','src/__tests__/scope-grammar.test.ts','src/__tests__/sql-pure.experiment.test.ts']
results=[]
try:
 for name,changes in [('original',{}),*variants.items()]:
  for key,path in files.items(): (R/path).write_text(changes.get(key,original[key]))
  for kind,paths in [('selected',original_tests),('focused',['src/__tests__/experiment-witnesses.test.ts'])]:
   output=D/f'local-{name}-{kind}.json'; log=D/f'local-{name}-{kind}.log'
   cmd=base+['--outputFile='+str(output)]+paths
   start=time.monotonic()
   with log.open('w') as out: run=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,timeout=45)
   report=json.loads(output.read_text())
   failures=[{'name':t['fullName'],'messages':t.get('failureMessages',[])} for f in report['testResults'] for t in f['assertionResults'] if t['status']=='failed']
   row={'variant':name,'suite':kind,'command':cmd,'exit_code':run.returncode,'seconds':round(time.monotonic()-start,3),'passed':report['numPassedTests'],'failed':report['numFailedTests'],'total':report['numTotalTests'],'failures':failures}
   results.append(row)
   print(name,kind,'passed',row['passed'],'failed',row['failed'],flush=True)
finally:
 for key,path in files.items(): (R/path).write_text(original[key])
 (D/'local-results.json').write_text(json.dumps(results,indent=2))
