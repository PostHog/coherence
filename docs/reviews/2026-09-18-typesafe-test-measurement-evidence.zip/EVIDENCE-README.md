# Test measurement experiment evidence

Interpretation is in REPORT.md. Cases f01-f12 have distinct test forms; f13 and f14 are name-only variations of f01 and f02. The single question is in question.json. cases.json stores labels separately from the submitted request bodies. No model classification labels, actual production implementation, or execution outcomes were supplied in requests/.

sources/ contains the controlled test variants, the helper omitted from f10's API input, and the original production files needed by the local comparisons. These were derived from Mnemion commit 02efce9da182ba7d543e47d8694f39ef9794ed46. variants.json records the deliberate changes. Historical scripts retain the original absolute temporary/dependency paths; adjust them before trying to reproduce local execution elsewhere. No application service is deployed or contacted by the tests.

To replay selected API inputs, supply a fresh key through the TYPESAFE_API_KEY environment variable without putting it in this archive, then run:

    python3 replay.py --out /tmp/test-measurement-replay --cases f01 f02

The helper writes new responses and times. It does not execute local tests. API use may incur charges; verify current availability and pricing. Source questions and cases were fixed before the original calls; no question was revised after seeing these results.
