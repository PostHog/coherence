from pathlib import Path
import subprocess,json,time,hashlib
D=Path('/tmp/coherence-test-measurement.ElPwKU');R=D/'snapshot/mnemion-js'
paths={'host':'shared/core/host.ts','sql':'shared/core/sql.ts','io':'shared/Routing/routes/io.ts'}
original={k:(R/v).read_text() for k,v in paths.items()}
variants={
 'baseline':{},
 'host_observed_first':{'host':original['host'].replace('if (configured && configured !== WORKER_HOST_PLACEHOLDER) return configured;','if (lastKnownHost) return lastKnownHost;\n  if (configured && configured !== WORKER_HOST_PLACEHOLDER) return configured;')},
 'sql_validation_removed':{'sql':original['sql'].replace('if (typeof name !== "string" || !IDENTIFIER_RE.test(name))\n    throw new Error(`Invalid SQL identifier: ${JSON.stringify(name)}`);','')},
 'io_resource_kind_changed':{'io':original['io'].replace('`read:entry:${ctx.params.pattern}:${ctx.params.id}`','`read:collection:${ctx.params.pattern}:${ctx.params.id}`')},
 'restored':{}
}
(D/'variants.json').write_text(json.dumps(variants,indent=2))
results=[]
try:
 for name,changes in variants.items():
  for k,p in paths.items(): (R/p).write_text(changes.get(k,original[k]))
  out=D/f'local-{name}.json';log=D/f'local-{name}.log'
  command=['node','/Users/daniloc/Documents/Dev/mnemion/mnemion-js/node_modules/vitest/vitest.mjs','run','--root',str(R),'--config',str(D/'vitest.config.mjs'),'--reporter=json','--outputFile='+str(out)]
  start=time.monotonic()
  with log.open('w') as f: cp=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,timeout=60)
  r=json.loads(out.read_text())
  row={'variant':name,'command':command,'exit_code':cp.returncode,'seconds':round(time.monotonic()-start,3),'passed':r['numPassedTests'],'failed':r['numFailedTests'],'total':r['numTotalTests'],'cases':{Path(t['name']).name.removeprefix('measurement-').removesuffix('.test.ts'):{'status':t['status'],'assertions':t['assertionResults']} for t in r['testResults']}}
  results.append(row);print(name,'passed',row['passed'],'failed',row['failed'],flush=True)
finally:
 for k,p in paths.items(): (R/p).write_text(original[k])
 (D/'local-results.json').write_text(json.dumps(results,indent=2))
 (D/'restoration.json').write_text(json.dumps({paths[k]:{'before_sha256':hashlib.sha256(v.encode()).hexdigest(),'after_sha256':hashlib.sha256((R/paths[k]).read_bytes()).hexdigest()} for k,v in original.items()},indent=2))
# Check the predeclared labels against executed sensitivity, rather than changing labels after inference.
by={r['variant']:r for r in results}
for c in json.loads((D/'cases.json').read_text()):
 mutation={'host':'host_observed_first','sql':'sql_validation_removed','population':'io_resource_kind_changed'}[c['family']]
 assert by['baseline']['cases'][c['id']]['status']=='passed', c['id']+' baseline failed'
 assert by['restored']['cases'][c['id']]['status']=='passed', c['id']+' restoration failed'
 actual=by[mutation]['cases'][c['id']]['status']=='failed'
 assert actual==c['expected_detects_controlled_change'],(c['id'],actual)
print('All expected sensitivity outcomes witnessed; all source hashes restored.',flush=True)
