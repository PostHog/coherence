"""Replay saved requests using TYPESAFE_API_KEY; never record authentication."""
import argparse,json,os,time,urllib.request
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('--evidence',type=Path,default=Path(__file__).parent)
p.add_argument('--out',type=Path,required=True)
p.add_argument('--cases',nargs='+',required=True,help='Explicit cases, e.g. f01 f02; at most 20')
a=p.parse_args()
if len(a.cases)>20: p.error('At most 20 requests per invocation')
if a.out.exists(): p.error('Output directory must not already exist')
requests=[]
for case in a.cases:
 if not __import__('re').fullmatch(r'[cf]\d{2}',case): p.error('Invalid case id')
 body=(a.evidence/'requests'/f'{case}.json').read_bytes()
 json.loads(body)
 requests.append((case,body))
key=os.environ.pop('TYPESAFE_API_KEY')
a.out.mkdir(parents=True)
for case,body in requests:
 request=urllib.request.Request('https://api.typesafe.ai/v1/systemone',data=body,headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'},method='POST')
 start=time.monotonic()
 with urllib.request.urlopen(request,timeout=90) as response: result=json.load(response)
 (a.out/f'{case}.json').write_text(json.dumps({'elapsed_seconds':time.monotonic()-start,'response':result},indent=2))
 print(case,'saved')
