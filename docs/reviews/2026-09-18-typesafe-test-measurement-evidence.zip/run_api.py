from pathlib import Path
import os,json,time,urllib.request,urllib.error,datetime
D=Path('/tmp/coherence-test-measurement.ElPwKU');key=os.environ.pop('TYPESAFE_API_KEY')
cases=json.loads((D/'cases.json').read_text());question=json.loads((D/'question.json').read_text())
(D/'requests').mkdir(exist_ok=True);(D/'responses').mkdir(exist_ok=True)
rows=[];attempts=0
meta={'model':'jev-1.13.0','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'max_http_attempts':16,'endpoint':'https://api.typesafe.ai/v1/systemone'}
try:
 for case in cases:
  payload={'model':meta['model'],'state':case['state'],'questions':{'measurement':question}}
  encoded=json.dumps(payload).encode();(D/'requests'/f"{case['id']}.json").write_bytes(encoded)
  for retry in range(2):
   if attempts>=16: raise RuntimeError('HTTP attempt cap reached')
   attempts+=1
   request=urllib.request.Request(meta['endpoint'],data=encoded,headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'},method='POST')
   start=time.monotonic()
   try:
    with urllib.request.urlopen(request,timeout=90) as response: result=json.load(response)
    row={'case_id':case['id'],'seconds':round(time.monotonic()-start,3),'http_attempt':attempts,'model':result.get('model'),'answer':result['answers']['measurement'],'usage':result.get('usage',{})}
    (D/'responses'/f"{case['id']}.json").write_text(json.dumps(result,indent=2));rows.append(row)
    print(case['id'],json.dumps(row),flush=True);break
   except urllib.error.HTTPError as exc:
    message=exc.read().decode(errors='replace').replace(key,'[REDACTED]')
    with (D/'errors.jsonl').open('a') as f:f.write(json.dumps({'case_id':case['id'],'status':exc.code,'message':message})+'\n')
    print('HTTP error',exc.code,message[:300],flush=True)
    if retry==0 and exc.code in (429,529,502,503):time.sleep(3);continue
    raise SystemExit('Stopped after HTTP failure; no additional requests.')
finally:
 (D/'api-results.json').write_text(json.dumps(rows,indent=2))
 meta.update({'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'http_attempts':attempts,'completed_cases':len(rows)})
 (D/'api-manifest.json').write_text(json.dumps(meta,indent=2));key=None
