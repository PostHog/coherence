export default {
  "cacheDir": "/tmp/coherence-test-measurement.ElPwKU/vite-cache",
  "test": {
    "environment": "node",
    "cache": false,
    "isolate": true,
    "maxWorkers": 1,
    "fileParallelism": false,
    "include": [
      "src/__tests__/measurement-*.test.ts"
    ]
  }
};
