import { it, expect } from "vitest";
import { readFileSync } from "node:fs";
const SHAPES: Array<[string, boolean, string]> = [
    // --- LEAF resource grants: name exactly one served resource → NARROW ---
    ["read:entry:axioms:7", false, "one shared entry (read:entry:<pattern>:<id>)"],
    ["read:output:feed", false, "one output (read:output:<path>)"],
    ["read:output:reports/2026/q2", false, "one output, slashed path"],
    ["read:publication:blog", false, "one publication (read:publication:<path>)"],
    ["read:document:42", false, "one document (read:document:<id>)"],
    ["write:input:webhook", false, "one ingress endpoint (write:input:<path>)"],

    // --- CLASS grants: name a whole subtree scopeMatches grants wholesale → BROAD ---
    ["read:entry:axioms", true, "THE BUG: a pattern-WIDE class key (every id in axioms)"],
    ["read:entry", true, "every entry in every pattern"],
    ["read:output", true, "every output"],
    ["read:publication", true, "every publication"],
    ["read:document", true, "every document"],
    ["write:input", true, "every ingress endpoint"],
    ["read", true, "the whole read class"],
    ["write", true, "the whole write class"],
    ["*", true, "full access — redeems as an owner login"],
    ["marketplace", true, "private marketplace git access"],

    // --- benign non-read/write scopes (target-bound / inert) → NARROW ---
    ["upload", false, "single-use upload, constraints frozen"],
    ["upload:x", false, "upload with a suffix, still target-bound"],
    ["document", false, "single-use document upload, constraints frozen"],
    ["document:x", false, "document with a suffix"],
    ["register", false, "minted inert, gated by /invite passkey approval"],

    // --- unknown / malformed shapes fail CLOSED (broad) ---
    ["", true, "empty string — unknown shape"],
    ["read:", true, "trailing-colon class key, no kind"],
    ["frobnicate", true, "unrecognized root"],
    ["read:entry:", true, "empty pattern segment — not a real leaf"],
  ];
it("the matrix covers every served required-scope kind in io.ts", () => {
 const ioSource = readFileSync(new URL("../../shared/Routing/routes/io.ts", import.meta.url), "utf8");
 const SERVED_KINDS = [...new Set([...ioSource.matchAll(/denyUnlessBearerScope\(ctx, `(?:read|write):([a-z]+):/g)].map(match => match[1]))];
 for (const kind of SERVED_KINDS) {
  const root = kind === "input" ? "write" : "read";
  const hasLeaf = SHAPES.some(([s, broad]) => !broad && s.startsWith(`${root}:${kind}:`));
  const hasClass = SHAPES.some(([s, broad]) => broad && s === `${root}:${kind}`);
  expect(hasLeaf).toBe(true);
  expect(hasClass).toBe(true);
 }
});
