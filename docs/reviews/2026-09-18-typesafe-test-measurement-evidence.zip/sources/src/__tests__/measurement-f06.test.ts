import { it, expect } from "vitest";
import { quoteIdent } from "../../shared/core/sql";
const BAD = ['x"; DROP TABLE y --', "a;b", "", "1col", undefined, null];
it("invalid identifiers are rejected", () => {
 for (const name of BAD) {
  expect(() => quoteIdent(name as any)).toThrow(/Invalid SQL identifier/);
 }
});
