import { it, expect } from "vitest";
import { quoteIdent } from "../../shared/core/sql";
it("invalid identifiers are rejected", () => {
 expect(quoteIdent("tasks")).toBe('"tasks"');
 expect(quoteIdent("due-date")).toBe('"due-date"');
});
