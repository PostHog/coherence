import { it, expect } from "vitest";
import { readFileSync } from "node:fs";
it("configured host wins over every spoofed input", () => {
 const source = readFileSync(new URL("../../shared/core/host.ts", import.meta.url), "utf8");
 expect(source).toContain("return configured");
 expect(source).toContain("WORKER_HOST_PLACEHOLDER");
});
