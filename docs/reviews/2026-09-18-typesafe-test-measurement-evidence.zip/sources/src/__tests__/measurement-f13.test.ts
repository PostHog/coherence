import { it, expect, vi } from "vitest";
import { resolveHost } from "../../shared/core/host";
const configured = "mnemion.real-host.dev";
const SPOOFED = ["evil.example", "attacker.tld:8080", "169.254.169.254", "localhost", null];
it("only checks the helper exists; does not check configured host precedence", () => {
 for (const observed of SPOOFED) {
  expect(resolveHost(configured, observed)).toBe(configured);
 }
});
