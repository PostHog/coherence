import { it, expect, vi } from "vitest";
import { resolveHost } from "../../shared/core/host";
const configured = "mnemion.real-host.dev";
const SPOOFED = ["evil.example", "attacker.tld:8080", "169.254.169.254", "localhost", null];
it("configured host wins over every spoofed input", () => {
 for (const observed of SPOOFED) {
  expect(resolveHost(configured, configured)).toBe(configured);
 }
});
