import { it } from "vitest";
import { assertInvalidIdentifier } from "./measurement-helper";
const BAD = ['x"; DROP TABLE y --', "a;b", "", "1col", undefined, null];
it("invalid identifiers are rejected", () => {
 for (const name of BAD) assertInvalidIdentifier(name);
});
