import { expect } from "vitest";
import { quoteIdent } from "../../shared/core/sql";
export function assertInvalidIdentifier(name: unknown) {
 expect(() => quoteIdent(name as any)).toThrow(/Invalid SQL identifier/);
}
